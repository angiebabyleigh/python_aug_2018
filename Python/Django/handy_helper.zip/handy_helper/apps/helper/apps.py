from django.apps import AppConfig


class HelperConfig(AppConfig):
    name = 'helper'
