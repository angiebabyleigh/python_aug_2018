from flask import Flask, render_template, request, redirect
import datetime
now = datetime.datetime.now()

app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():	
	print(request.form)

	name_last=request.form['last_name']
	name_first=request.form['first_name']
	app_num=int(request.form['apple'])
	rasp_num=int(request.form['raspberry'])
	straw_num=int(request.form['strawberry'])
	num=app_num + rasp_num + straw_num
	std_id=request.form['student_id']
	return render_template("checkout.html", dt_stamp=str(now), num=num, name_last=name_last, name_first=name_first, std_id=std_id, straw_num=straw_num, rasp_num=rasp_num, app_num=app_num)


@app.route('/fruits')         
def fruits():
    print(request.form)
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    


